package za.ac.cput.safestaystudentapplication.gui;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import java.util.List;
import za.ac.cput.safestaystudentapplication.dao.AccommodationDAO;
import za.ac.cput.safestaystudentapplication.domain.Accommodation;

/**
 *
 * @author ntand
 */
public class AccommodationListingsGUI extends JFrame{
    
    private AccommodationDAO dao = new AccommodationDAO();
    private JPanel listingsPanel;

    public AccommodationListingsGUI() {

        setTitle("SafeStay - Accommodation");
        setSize(750, 950);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Top bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(new Color(20, 75, 160));
        topBar.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel title = new JLabel("SafeStay");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 24));

        JLabel pageTitle = new JLabel("Accommodation");
        pageTitle.setForeground(Color.WHITE);
        pageTitle.setFont(new Font("Arial", Font.BOLD, 18));

        topBar.add(title, BorderLayout.WEST);
        topBar.add(pageTitle, BorderLayout.EAST);

        // Listings
        listingsPanel = new JPanel();
        listingsPanel.setLayout(new BoxLayout(listingsPanel, BoxLayout.Y_AXIS));
        listingsPanel.setBackground(Color.WHITE);
        listingsPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JScrollPane scrollPane = new JScrollPane(listingsPanel);
        scrollPane.setBorder(null);

        add(topBar, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        loadAccommodations();
    }

    private void loadAccommodations() {

        List<Accommodation> accommodations = dao.getAllAccommodations();

        for (Accommodation accommodation : accommodations) {

            JPanel card = new JPanel(new BorderLayout(15, 10));
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(220, 220, 220)),
                    new EmptyBorder(15, 15, 15, 15)
            ));

            JLabel name = new JLabel(accommodation.getName());
            name.setFont(new Font("Arial", Font.BOLD, 20));

            JLabel address = new JLabel(accommodation.getAddress());
            address.setFont(new Font("Arial", Font.PLAIN, 14));

            JLabel price = new JLabel(
                    "R " + accommodation.getPrice() + " / month"
            );
            price.setFont(new Font("Arial", Font.BOLD, 16));
            price.setForeground(new Color(20, 75, 160));

            JButton viewButton = new JButton("VIEW DETAILS");
            viewButton.setBackground(new Color(20, 75, 160));
            viewButton.setForeground(Color.WHITE);
            viewButton.setFocusPainted(false);

            viewButton.addActionListener(e -> {
                AccommodationGUI details =
                        new AccommodationGUI(accommodation);
                details.setVisible(true);
            });

            JPanel info = new JPanel();
            info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
            info.setBackground(Color.WHITE);

            info.add(name);
            info.add(Box.createVerticalStrut(8));
            info.add(address);
            info.add(Box.createVerticalStrut(8));
            info.add(price);

            card.add(info, BorderLayout.CENTER);
            card.add(viewButton, BorderLayout.EAST);

            listingsPanel.add(card);
            listingsPanel.add(Box.createVerticalStrut(15));
        }

        listingsPanel.revalidate();
        listingsPanel.repaint();
    }

    public static void main(String[] args) {
        new AccommodationListingsGUI().setVisible(true);
    }
}