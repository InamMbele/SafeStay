package za.ac.cput.safestaystudentapplication.gui;
import java.awt.*;
import java.time.LocalDate;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import za.ac.cput.safestaystudentapplication.dao.AccommodationDAO;
import za.ac.cput.safestaystudentapplication.domain.Accommodation;

/**
 *
 * @author ntand
 */
public class AccommodationManagementGUI extends JFrame {
    
    private JTextField txtAccommodationID, txtLandlordID, txtName, txtAddress, txtPrice, txtNumberOfRooms, txtRoomType, txtDistanceToCampus, txtMoveInDate, 
            txtPropertyRules, txtAvailabilityStatus, txtDateListed, txtImagePath;
    private JComboBox<String> cmbLandlord;
    private JLabel lblLandlordNameValue, lblLandlordEmailValue, lblLandlordPhoneValue, lblLandlordDateValue;
    private JButton btnAdd, btnRetrieve, btnUpdate, btnDelete, btnClear;
    private AccommodationDAO dao;
    
    public AccommodationManagementGUI() {

        dao = new AccommodationDAO();

        setTitle("SafeStay - Manage Accommodation");
        setSize(750, 850);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        createGUI();
    }

    private void createGUI() {

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);

        // TOP BAR
       
        JPanel topPanel = new JPanel(new BorderLayout());

        topPanel.setBackground(
                new Color(20, 75, 160)
        );

        topPanel.setBorder(
                new EmptyBorder(15, 20, 15, 20)
        );

        JLabel lblTitle = new JLabel(
                "Manage Accommodation",
                SwingConstants.CENTER
        );
        
        lblTitle.setForeground(Color.WHITE);

        lblTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        20
                )
        );

        JButton btnBack = new JButton("BACK");

        btnBack.setForeground(Color.WHITE);
        btnBack.setBackground(
                new Color(20, 75, 160)
        );

        btnBack.setBorderPainted(false);
        btnBack.setFocusPainted(false);

        btnBack.addActionListener(
                e -> dispose()
        );
        
        topPanel.add(
                btnBack,
                BorderLayout.WEST
        );

        topPanel.add(
                lblTitle,
                BorderLayout.CENTER
        );

        mainPanel.add(
                topPanel,
                BorderLayout.NORTH
        );

        
        // FORM

        JPanel formPanel = new JPanel(
                new GridLayout(
                        14,
                        2,
                        10,
                        10
                )
        );
        
        formPanel.setBackground(Color.WHITE);

        formPanel.setBorder(
                new EmptyBorder(
                        20,
                        30,
                        20,
                        30
                )
        );

        txtAccommodationID = createTextField();
        txtLandlordID = createTextField();
        
        cmbLandlord = new JComboBox<>();
        loadLandlords();
        
        txtName = createTextField();
        txtAddress = createTextField();
        txtPrice = createTextField();
        txtNumberOfRooms = createTextField();
        txtRoomType = createTextField();
        txtDistanceToCampus = createTextField();
        txtMoveInDate = createTextField();
        txtPropertyRules = createTextField();
        txtAvailabilityStatus = createTextField();
        txtDateListed = createTextField();
        txtImagePath = createTextField();
        
        txtLandlordID.setVisible(false);

        lblLandlordNameValue = new JLabel("Name: Not selected");
        lblLandlordEmailValue = new JLabel("Email: Not selected");
        lblLandlordPhoneValue = new JLabel("Phone: Not selected");
        lblLandlordDateValue = new JLabel("Registered: Not selected");
        
        JPanel landlordPanel = createLandlordDisplayPanel();

        formPanel.add(new JLabel("Landlord Details:"));
        formPanel.add(landlordPanel);

        addFormRow(
                formPanel,
                "Accommodation ID:",
                txtAccommodationID
        );

        formPanel.add(new JLabel("Landlord:"));
        formPanel.add(cmbLandlord);

        addFormRow(
                formPanel,
                "Name:",
                txtName
        );

        addFormRow(
                formPanel,
                "Address:",
                txtAddress
        );

        addFormRow(
                formPanel,
                "Price:",
                txtPrice
        );
        
        addFormRow(
                formPanel,
                "Number of Rooms:",
                txtNumberOfRooms
        );

        addFormRow(
                formPanel,
                "Room Type:",
                txtRoomType
        );

        addFormRow(
                formPanel,
                "Distance to Campus:",
                txtDistanceToCampus
        );

        addFormRow(
                formPanel,
                "Move-in Date:",
                txtMoveInDate
        );

        addFormRow(
                formPanel,
                "Property Rules:",
                txtPropertyRules
        );

        addFormRow(
                formPanel,
                "Availability Status:",
                txtAvailabilityStatus
        );

        addFormRow(
                formPanel,
                "Date Listed:",
                txtDateListed
        );

        addFormRow(
                formPanel,
                "Image Path:",
                txtImagePath
        );

        JScrollPane scrollPane =
                new JScrollPane(formPanel);

        scrollPane.setBorder(null);
        
        mainPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        // BUTTONS

        JPanel buttonPanel = new JPanel(
                new GridLayout(
                        1,
                        5,
                        10,
                        0
                )
        );

        buttonPanel.setBackground(Color.WHITE);

        buttonPanel.setBorder(
                new EmptyBorder(
                        10,
                        30,
                        20,
                        30
                )
        );

        btnAdd = new JButton("ADD");
        btnRetrieve = new JButton("RETRIEVE");
        btnUpdate = new JButton("UPDATE");
        btnDelete = new JButton("DELETE");
        btnClear = new JButton("CLEAR");

        styleButton(
                btnAdd,
                new Color(50, 170, 80)
        );

        styleButton(
                btnRetrieve,
                new Color(20, 75, 160)
        );

        styleButton(
                btnUpdate,
                new Color(230, 150, 30)
        );

        styleButton(
                btnDelete,
                new Color(210, 40, 40)
        );

        styleButton(
                btnClear,
                new Color(100, 100, 100)
        );

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnRetrieve);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnClear);

        mainPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );

        add(mainPanel);
        
        // BUTTON ACTIONS

        btnAdd.addActionListener(e -> addAccommodation());

        btnRetrieve.addActionListener(e -> retrieveAccommodation());

        btnUpdate.addActionListener(e -> updateAccommodation());

        btnDelete.addActionListener(e -> deleteAccommodation());

        btnClear.addActionListener(e -> clearFields());
    }
    
    // LANDLORD DISPLAY

    private JPanel createLandlordDisplayPanel() {

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1, 3, 3));
        panel.setBackground(Color.WHITE);

        lblLandlordNameValue.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );

        lblLandlordEmailValue.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );

        lblLandlordPhoneValue.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );

        lblLandlordDateValue.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );

        panel.add(lblLandlordNameValue);
        panel.add(lblLandlordEmailValue);
        panel.add(lblLandlordPhoneValue);
        panel.add(lblLandlordDateValue);

        return panel;
    }
    
    private void loadLandlords() {

        cmbLandlord.removeAllItems();

        cmbLandlord.addItem("Select Landlord");

        Object[][] landlords = dao.getAllLandlords();

        if (landlords != null) {

            for (Object[] landlord : landlords) {

                int landlordID =
                        Integer.parseInt(
                                landlord[0].toString()
                        );

                String firstName =
                        landlord[1].toString();

                String lastName =
                        landlord[2].toString();

                cmbLandlord.addItem(
                        landlordID + " - "
                        + firstName + " "
                        + lastName
                );
            }
        }
    }

    
    // CREATE TEXT FIELD

    private JTextField createTextField() {

        JTextField field = new JTextField();

        field.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        return field;
    }

    // ==========================================
    // ADD FORM ROW
    // ==========================================

    private void addFormRow(
            JPanel panel,
            String label,
            JTextField field) {

        JLabel lbl = new JLabel(label);

        lbl.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        panel.add(lbl);
        panel.add(field);
    }

    // ==========================================
    // STYLE BUTTON
    // ==========================================

    private void styleButton(
            JButton button,
            Color background) {

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(Color.WHITE);
        button.setBackground(background);

        button.setBorderPainted(false);
        button.setFocusPainted(false);

        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );
    }

    // ADD

    private void addAccommodation() {

        try {
            
            int selectedIndex = cmbLandlord.getSelectedIndex();

            if (selectedIndex == 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "Please select a landlord.",
                        "Input Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            String selectedLandlord =
                    cmbLandlord.getSelectedItem().toString();

            int landlordID =
                    Integer.parseInt(
                            selectedLandlord.split(" - ")[0]
                    );

            txtLandlordID.setText(String.valueOf(landlordID));

            Accommodation accommodation =
                    new Accommodation(
                            0,
                            landlordID,
                            txtAddress.getText(),
                            txtName.getText(),
                            Double.parseDouble(
                                    txtPrice.getText()
                            ),
                            Integer.parseInt(
                                    txtNumberOfRooms.getText()
                            ),
                            txtRoomType.getText(),
                            Double.parseDouble(
                                    txtDistanceToCampus.getText()
                            ),
                            LocalDate.parse(
                                    txtMoveInDate.getText()
                            ),
                            txtPropertyRules.getText(),
                            txtAvailabilityStatus.getText(),
                            LocalDate.parse(
                                    txtDateListed.getText()
                            ),
                            txtImagePath.getText()
                    );

            boolean result =
                    dao.addAccommodation(
                            accommodation
                    );

            if (result) {

                JOptionPane.showMessageDialog(
                        this,
                        "Accommodation added successfully!"
                );

                clearFields();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Accommodation could not be added.",
                        "Add",
                        JOptionPane.ERROR_MESSAGE
                );
            }

        } catch (Exception e) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Please check your information.\n"
                            + "Dates must use YYYY-MM-DD.",
                            "Input Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            }

            private void selectLandlord(int landlordID) {

            for (int i = 0; i < cmbLandlord.getItemCount(); i++) {

                String item =
                        cmbLandlord.getItemAt(i);

                if (item.startsWith(
                        landlordID + " - "
                )) {

                    cmbLandlord.setSelectedIndex(i);
                    return;
                }
            }
        }

    // ==========================================
    // RETRIEVE
    // ==========================================

    private void retrieveAccommodation() {

        try {

            int accommodationID =
                    Integer.parseInt(
                            txtAccommodationID.getText()
                    );

            Accommodation result =
                    dao.getAccommodationById(
                            accommodationID
                    );

            if (result != null) {

                fillFields(result);

                JOptionPane.showMessageDialog(
                        this,
                        "Accommodation retrieved successfully!"
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Accommodation not found.",
                        "Retrieve",
                        JOptionPane.WARNING_MESSAGE
                );
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid Accommodation ID.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ==========================================
    // FILL FIELDS
    // ==========================================

    private void fillFields(
            Accommodation accommodation) {

        txtAccommodationID.setText(
                String.valueOf(
                        accommodation.getAccommodationID()
                )
        );

        txtLandlordID.setText(
                String.valueOf(
                        accommodation.getLandlordID()
                )
        );
        
        selectLandlord(accommodation.getLandlordID());
        
        loadLandlordDetails(accommodation.getAccommodationID());

        txtName.setText(
                accommodation.getName()
        );

        txtAddress.setText(
                accommodation.getAddress()
        );

        txtPrice.setText(
                String.valueOf(
                        accommodation.getPrice()
                )
        );

        txtNumberOfRooms.setText(
                String.valueOf(
                        accommodation.getNumberOfRooms()
                )
        );

        txtRoomType.setText(
                accommodation.getRoomType()
        );

        txtDistanceToCampus.setText(
                String.valueOf(
                        accommodation.getDistanceToCampus()
                )
        );

        if (accommodation.getMoveInDate() != null) {

            txtMoveInDate.setText(
                    accommodation.getMoveInDate().toString()
            );

        } else {

            txtMoveInDate.setText("");
        }

        txtPropertyRules.setText(
                accommodation.getPropertyRules()
        );

        txtAvailabilityStatus.setText(
                accommodation.getAvailabilityStatus()
        );

        if (accommodation.getDateListed() != null) {

            txtDateListed.setText(
                    accommodation.getDateListed().toString()
            );

        } else {

            txtDateListed.setText("");
        }

        txtImagePath.setText(
                accommodation.getImagePath()
        );
    }
    
    // ==========================================
    // LOAD LANDLORD DETAILS
    // ==========================================

    private void loadLandlordDetails(int accommodationID) {

        Object[] landlordDetails =
                dao.getLandlordDetails(accommodationID);

        if (landlordDetails != null) {

            String firstName =
                    String.valueOf(landlordDetails[0]);

            String lastName =
                    String.valueOf(landlordDetails[1]);

            lblLandlordNameValue.setText(
                    "Name: " + firstName + " " + lastName
            );

            lblLandlordEmailValue.setText(
                    "Email: " + String.valueOf(landlordDetails[2])
            );

            lblLandlordPhoneValue.setText(
                    "Phone: " + String.valueOf(landlordDetails[3])
            );

            if (landlordDetails[4] != null) {

                lblLandlordDateValue.setText(
                        "Registered: "
                        + landlordDetails[4].toString()
                );

            } else {

                lblLandlordDateValue.setText(
                        "Registered: Not available"
                );
            }

        } else {

            lblLandlordNameValue.setText(
                    "Name: Not found"
            );

            lblLandlordEmailValue.setText(
                    "Email: Not found"
            );

            lblLandlordPhoneValue.setText(
                    "Phone: Not found"
            );

            lblLandlordDateValue.setText(
                    "Registered: Not found"
            );
        }
    }

    // UPDATE
    private int getSelectedLandlordID() {

        if (cmbLandlord.getSelectedIndex() <= 0) {
            throw new IllegalArgumentException("Please select a landlord.");
        }

        String selectedLandlord =
                cmbLandlord.getSelectedItem().toString();

        return Integer.parseInt(
                selectedLandlord.split(" - ")[0]
        );
    }

    private void updateAccommodation() {

        try {

            Accommodation accommodation =
                    new Accommodation(
                            Integer.parseInt(
                                    txtAccommodationID.getText()
                            ),
                            getSelectedLandlordID(),
                            txtAddress.getText(),
                            txtName.getText(),
                            Double.parseDouble(
                                    txtPrice.getText()
                            ),
                            Integer.parseInt(
                                    txtNumberOfRooms.getText()
                            ),
                            txtRoomType.getText(),
                            Double.parseDouble(
                                    txtDistanceToCampus.getText()
                            ),
                            LocalDate.parse(
                                    txtMoveInDate.getText()
                            ),
                            txtPropertyRules.getText(),
                            txtAvailabilityStatus.getText(),
                            LocalDate.parse(
                                    txtDateListed.getText()
                            ),
                            txtImagePath.getText()
                    );

            boolean result =
                    dao.updateAccommodation(
                            accommodation
                    );

            if (result) {

                JOptionPane.showMessageDialog(
                        this,
                        "Accommodation updated successfully!"
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Accommodation could not be updated.",
                        "Update",
                        JOptionPane.ERROR_MESSAGE
                );
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please check your information.\n"
                    + "Dates must use YYYY-MM-DD.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // DELETE

    private void deleteAccommodation() {
        try {

            int accommodationID = Integer.parseInt(txtAccommodationID.getText());

            int confirmation =
                    JOptionPane.showConfirmDialog(
                            this,
                            "Are you sure you want to delete "
                            + "Accommodation ID "
                            + accommodationID
                            + "?",
                            "Confirm Delete",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE
                    );
            
            if (confirmation != JOptionPane.YES_OPTION) {
                return;
            }
            
            boolean deleted = dao.deleteAccommodation(accommodationID);

            if (deleted) {
                JOptionPane.showMessageDialog(this, "Accommodation deleted successfully!");

                clearFields();

            } else {
                JOptionPane.showMessageDialog(this, "Accommodation not found.", "Delete", JOptionPane.WARNING_MESSAGE);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid Accommodation ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==========================================
    // CLEAR
    // ==========================================

    private void clearFields() {

        txtAccommodationID.setText("");
        txtLandlordID.setText("");
        txtName.setText("");
        txtAddress.setText("");
        txtPrice.setText("");
        txtNumberOfRooms.setText("");
        txtRoomType.setText("");
        txtDistanceToCampus.setText("");
        txtMoveInDate.setText("");
        txtPropertyRules.setText("");
        txtAvailabilityStatus.setText("");
        txtDateListed.setText("");
        txtImagePath.setText("");
        
        lblLandlordNameValue.setText("Not selected");
        lblLandlordEmailValue.setText("Not selected");
        lblLandlordPhoneValue.setText("Not selected");
        lblLandlordDateValue.setText("Not selected");
    }

    // ==========================================
    // MAIN
    // ==========================================

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new AccommodationManagementGUI()
                    .setVisible(true);

        });
    }
    
}


