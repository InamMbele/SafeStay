package za.ac.cput.safestaystudentapplication.dao;
import java.time.LocalDate;
import za.ac.cput.safestaystudentapplication.domain.Accommodation;
/**
 *
 * @author ntando matiwane
 * @studnr 250595699
 */
public class TestAccommodationDAO {
    
    public static void main(String[] args) {

        AccommodationDAO dao = new AccommodationDAO();

        // UPDATE accommodationID 1
        Accommodation accommodation = new Accommodation(
            1,
            1,
            "Cape Town",
            "SafeStay Student House",
            4500.00,
            4,
            "Single Room",
            2.5,
            LocalDate.of(2026, 9, 1),
            "No smoking",
            "Available",
            LocalDate.now(),
            "studenthouse.jpg"
        );
        
        boolean updated = dao.updateAccommodation(accommodation);

        System.out.println("UPDATE: " + updated);

        // RETRIEVE
        Accommodation updatedAccommodation =
                dao.getAccommodationById(1);

        System.out.println("\nUPDATED ACCOMMODATION:");
        System.out.println(updatedAccommodation);
    
    }
}
