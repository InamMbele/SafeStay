package za.ac.cput.safestaystudentapplication.connection;
import java.sql.Connection;
/**
 *
 * @author ntando matiwane
 * @studnr 250595699
 */
public class TestConnection {
    
    public static void main(String[] args) {

        try {
            Connection connection =
                    DatabaseConnection.getConnection();

            System.out.println("Database connection successful!");

            connection.close();

        } catch (Exception e) {
            System.out.println("Database connection failed!");
            e.printStackTrace();
        }
    }
}
