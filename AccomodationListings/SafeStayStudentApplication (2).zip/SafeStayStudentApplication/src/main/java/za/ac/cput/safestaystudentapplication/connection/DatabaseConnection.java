package za.ac.cput.safestaystudentapplication.connection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author ntando matiwane
 * @studnr 250595699
 */
public class DatabaseConnection {
    
    private static final String URL =
            "jdbc:mysql://localhost:3306/SAFESTAY";

    private static final String USER = "root";

    private static final String PASSWORD = "Nonkosazana_81*";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
