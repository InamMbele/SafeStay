package za.ac.cput.safestaystudentapplication.gui;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.io.File;
import java.time.LocalDate;
import za.ac.cput.safestaystudentapplication.dao.AccommodationDAO;
import za.ac.cput.safestaystudentapplication.domain.Accommodation;
/**
 *
 * @author ntando matiwane
 * @studnr 250595699
 */
public class AccommodationGUI extends JFrame {
   
    //LABELS
    private JLabel lblAccommodationID, lblLandlordID, lblName, lblAddress, lblPrice, lblNumberOfRooms, lblRoomType, lblDistanceToCampus,  lblMoveInDate,
            lblPropertyRules, lblAvailabilityStatus, lblDateListed, lblImagePath, lblStatus, lblImage, lblLocation, lblMoveInValue, 
            lblRoomTypeValue, lblRoomsValue;
    private JLabel lblLandlordName, lblLandlordEmail, lblLandlordPhone, lblLandlordDate;

    public AccommodationGUI() {

        setTitle("SafeStay - Accommodation Listings");
        setSize(750, 950);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        createGUI();
    }
    
    public AccommodationGUI(Accommodation accommodation) {
        this();
        loadAccommodationDetails(accommodation);
    }
    
    // CREATE GUI
    private void createGUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);

        // TOP BAR

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(20, 75, 160));
        topPanel.setBorder(
                new EmptyBorder(12, 15, 15, 15)
        );

        JButton btnBack = new JButton("BACK");

        btnBack.setForeground(Color.WHITE);
        btnBack.setBackground(new Color(20, 75, 160));
        btnBack.setFont(
                new Font("Arial", Font.BOLD, 13)
        );
        btnBack.setBorderPainted(false);
        btnBack.setFocusPainted(false);
        btnBack.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );

        btnBack.addActionListener(e -> dispose());

        JLabel lblTitle = new JLabel(
                "Listing Details",
                SwingConstants.CENTER
        );

        lblTitle.setFont(
                new Font("Arial", Font.BOLD, 20)
        );

        lblTitle.setForeground(Color.WHITE);

        JPanel rightPanel = new JPanel(
                new FlowLayout(
                        FlowLayout.RIGHT,
                        5,
                        0
                )
        );

        rightPanel.setBackground(
                new Color(20, 75, 160)
        );

        JButton btnFavourite = new JButton("FAVOURITE");
        JButton btnShare = new JButton("SHARE");

        btnFavourite.setForeground(Color.WHITE);
        btnShare.setForeground(Color.WHITE);

        btnFavourite.setBackground(
                new Color(20, 75, 160)
        );

        btnShare.setBackground(
                new Color(20, 75, 160)
        );

        btnFavourite.setBorderPainted(false);
        btnShare.setBorderPainted(false);

        btnFavourite.setFocusPainted(false);
        btnShare.setFocusPainted(false);

        btnFavourite.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );

        btnShare.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );

        rightPanel.add(btnFavourite);
        rightPanel.add(btnShare);

        topPanel.add(
                btnBack,
                BorderLayout.WEST
        );

        topPanel.add(
                lblTitle,
                BorderLayout.CENTER
        );

        topPanel.add(
                rightPanel,
                BorderLayout.EAST
        );

        mainPanel.add(
                topPanel,
                BorderLayout.NORTH
        );

        // ==========================================
        // SCROLLABLE CONTENT
        // ==========================================

        JPanel content = new JPanel();

        content.setLayout(
                new BoxLayout(
                        content,
                        BoxLayout.Y_AXIS
                )
        );

        content.setBackground(Color.WHITE);

        content.setBorder(
                new EmptyBorder(
                        20,
                        25,
                        20,
                        25
                )
        );

        // ==========================================
        // IMAGE
        // ==========================================

        JPanel imagePanel = new JPanel(
                new BorderLayout()
        );

        imagePanel.setBackground(
                new Color(245, 245, 245)
        );

        imagePanel.setPreferredSize(
                new Dimension(680, 240)
        );

        imagePanel.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        240
                )
        );

        lblImage = new JLabel(
                "PROPERTY IMAGE",
                SwingConstants.CENTER
        );

        lblImage.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        22
                )
        );

        lblImage.setForeground(Color.GRAY);

        imagePanel.add(
                lblImage,
                BorderLayout.CENTER
        );

        content.add(imagePanel);

        content.add(
                Box.createVerticalStrut(15)
        );

        // ==========================================
        // NAME + STATUS
        // ==========================================

        JPanel namePanel =
                new JPanel(new BorderLayout());

        namePanel.setBackground(Color.WHITE);

        namePanel.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        45
                )
        );

        lblName = new JLabel(
                "Accommodation Name"
        );

        lblName.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );

        lblStatus = new JLabel(
                "STATUS",
                SwingConstants.CENTER
        );

        lblStatus.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        lblStatus.setForeground(Color.WHITE);

        lblStatus.setBackground(
                new Color(50, 170, 80)
        );

        lblStatus.setOpaque(true);

        lblStatus.setBorder(
                new EmptyBorder(
                        6,
                        10,
                        6,
                        10
                )
        );

        namePanel.add(
                lblName,
                BorderLayout.WEST
        );

        namePanel.add(
                lblStatus,
                BorderLayout.EAST
        );

        content.add(namePanel);

        content.add(
                Box.createVerticalStrut(8)
        );

        // ==========================================
        // PRICE
        // ==========================================

        lblPrice = new JLabel(
                "R 0.00 / month"
        );

        lblPrice.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        24
                )
        );

        lblPrice.setForeground(
                new Color(20, 75, 160)
        );

        lblPrice.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblPrice.setHorizontalAlignment(SwingConstants.LEFT);
        lblPrice.setMaximumSize(new Dimension(Integer.MAX_VALUE, 35));

        content.add(lblPrice);

        content.add(
                Box.createVerticalStrut(8)
        );

        // ==========================================
        // LOCATION
        // ==========================================

        lblLocation = new JLabel(
                "Address • 0.0 km from campus"
        );

        lblLocation.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        lblLocation.setForeground(
                new Color(105, 112, 122)
        );

        lblLocation.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblLocation.setHorizontalAlignment(SwingConstants.LEFT);
        lblLocation.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));

        content.add(lblLocation);

        content.add(
                Box.createVerticalStrut(15)
        );

        // ==========================================
        // INFORMATION CARDS
        // ==========================================

        JPanel infoPanel =
                new JPanel(
                        new GridLayout(
                                1,
                                3,
                                15,
                                0
                        )
                );

        infoPanel.setBackground(Color.WHITE);

        infoPanel.setPreferredSize(
                new Dimension(680, 75)
        );

        infoPanel.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        75
                )
        );

        JPanel moveInCard =
                createInfoCard(
                        "MOVE-IN",
                        "N/A"
                );

        JPanel roomTypeCard =
                createInfoCard(
                        "ROOM TYPE",
                        "N/A"
                );

        JPanel roomsCard =
                createInfoCard(
                        "ROOMS",
                        "0"
                );

        infoPanel.add(moveInCard);
        infoPanel.add(roomTypeCard);
        infoPanel.add(roomsCard);

        content.add(infoPanel);

        content.add(
                Box.createVerticalStrut(15)
        );
     
        // PROPERTY RULES
        JPanel rulesPanel = new JPanel();
        
        rulesPanel.setLayout(new BoxLayout(rulesPanel, BoxLayout.Y_AXIS));
        rulesPanel.setBackground(Color.WHITE);
        rulesPanel.setBorder(new EmptyBorder(0, 0, 0, 0));
        rulesPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        rulesPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 55));

        JLabel lblRules =
                new JLabel(
                        "Property Rules"
                );

        lblRules.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        19
                )
        );

        lblRules.setForeground(
                new Color(35, 42, 52)
        );

        lblRules.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        lblPropertyRules =
                new JLabel(
                        "<html>No rules provided.</html>"
                );

        lblPropertyRules.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        lblPropertyRules.setForeground(
                new Color(80, 85, 95)
        );

        lblPropertyRules.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblPropertyRules.setHorizontalAlignment(SwingConstants.LEFT);
        lblPropertyRules.setMaximumSize(new Dimension(Integer.MAX_VALUE,40));
        
        rulesPanel.add(lblRules);
        rulesPanel.add(Box.createVerticalStrut(2));
        rulesPanel.add(lblPropertyRules);

        content.add(rulesPanel);

        // ==========================================
        // LANDLORD
        // ==========================================

        JPanel landlordPanel = new JPanel();

        landlordPanel.setLayout(
                new BoxLayout(
                        landlordPanel,
                        BoxLayout.Y_AXIS
                )
        );

        landlordPanel.setBackground(Color.WHITE);
        
        landlordPanel.setBorder(
                new EmptyBorder(0, 0, 0, 0)
        );

        landlordPanel.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        landlordPanel.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        125
                )
        );

        // LANDLORD HEADING
        JLabel lblLandlord =
                new JLabel("Landlord");

        lblLandlord.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        19
                )
        );

        lblLandlord.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        landlordPanel.add(lblLandlord);

        landlordPanel.add(
                Box.createVerticalStrut(2)
        );

        // LANDLORD NAME
        lblLandlordName =
                new JLabel("Name: Not available");

        lblLandlordName.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        lblLandlordName.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        landlordPanel.add(lblLandlordName);

        landlordPanel.add(
                Box.createVerticalStrut(2)
        );

        // LANDLORD EMAIL
        lblLandlordEmail =
                new JLabel("Email: Not available");

        lblLandlordEmail.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        lblLandlordEmail.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        landlordPanel.add(lblLandlordEmail);

        landlordPanel.add(
                Box.createVerticalStrut(2)
        );

        // LANDLORD PHONE
        lblLandlordPhone =
                new JLabel("Phone: Not available");

        lblLandlordPhone.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        lblLandlordPhone.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        landlordPanel.add(lblLandlordPhone);

        landlordPanel.add(
                Box.createVerticalStrut(2)
        );

        // DATE REGISTERED
        lblLandlordDate =
                new JLabel("Registered: Not available");

        lblLandlordDate.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        lblLandlordDate.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        landlordPanel.add(lblLandlordDate);

        content.add(landlordPanel);

        content.add(
                Box.createVerticalStrut(15)
        );

        // ==========================================
        // SCROLL PANE
        // ==========================================

        JScrollPane scrollPane =
                new JScrollPane(content);

        scrollPane.setBorder(null);

        scrollPane.getViewport().setBackground(Color.WHITE);

        scrollPane.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
        );

        scrollPane.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
        );

        mainPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        add(mainPanel);
    }

    // ==========================================
    // INFORMATION CARD
    // ==========================================

    private JPanel createInfoCard(
            String title,
            String value) {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setBackground(Color.WHITE);

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        225,
                                        229,
                                        235
                                )
                        ),
                        BorderFactory.createEmptyBorder(
                                10,
                                8,
                                10,
                                8
                        )
                )
        );

        JLabel lblTitle =
                new JLabel(
                        title,
                        SwingConstants.CENTER
                );

        lblTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        lblTitle.setForeground(
                new Color(
                        105,
                        112,
                        122
                )
        );

        JLabel lblValue =
                new JLabel(
                        value,
                        SwingConstants.CENTER
                );

        // CONNECT THE CARD TO THE DATABASE VALUE
        if (title.equals("MOVE-IN")) {
            lblMoveInValue = lblValue;
        } else if (title.equals("ROOM TYPE")) {
            lblRoomTypeValue = lblValue;
        } else if (title.equals("ROOMS")) {
            lblRoomsValue = lblValue;
        }

        lblValue.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        lblValue.setForeground(
                new Color(
                        35,
                        42,
                        52
                )
        );

        panel.add(
                lblTitle,
                BorderLayout.NORTH
        );

        panel.add(
                lblValue,
                BorderLayout.CENTER
        );

        return panel;
    }

    // ==========================================
    // LOAD DETAILS
    // ==========================================

    private void loadAccommodationDetails(
            Accommodation accommodation) {

        // NAME
        String name =
                accommodation.getName();

        if (name == null ||
                name.trim().isEmpty()) {

            name = "Unnamed Accommodation";
        }

        lblName.setText(name);

        // STATUS
        String status =
                accommodation.getAvailabilityStatus();

        if (status == null ||
                status.trim().isEmpty()) {

            status = "Unknown";
        }

        lblStatus.setText(status);

        // PRICE
        lblPrice.setText(
                String.format(
                        "R %.2f / month",
                        accommodation.getPrice()
                )
        );

        // LOCATION
        String address =
                accommodation.getAddress();

        if (address == null ||
                address.trim().isEmpty()) {

            address = "Address unavailable";
        }

        lblLocation.setText(
                address
                + "  •  "
                + accommodation.getDistanceToCampus()
                + " km from campus"
        );

        // MOVE-IN DATE
        if (accommodation.getMoveInDate() != null) {

            lblMoveInValue.setText(
                    accommodation.getMoveInDate().toString()
            );

        } else {

            lblMoveInValue.setText("N/A");
        }

        // ROOM TYPE
        if (accommodation.getRoomType() != null &&
                !accommodation.getRoomType().trim().isEmpty()) {

            lblRoomTypeValue.setText(
                    accommodation.getRoomType()
            );

        } else {

            lblRoomTypeValue.setText("N/A");
        }

        // NUMBER OF ROOMS
        lblRoomsValue.setText(
                String.valueOf(
                        accommodation.getNumberOfRooms()
                )
        );

        // PROPERTY RULES
        String rules =
                accommodation.getPropertyRules();

        if (rules == null ||
                rules.trim().isEmpty()) {

            rules = "No rules provided.";
        }

        lblPropertyRules.setText(
                "<html>"
                + rules
                + "</html>"
        );

        // LANDLORD
        loadLandlordDetails(
                accommodation.getAccommodationID()
        );
        
        // IMAGE
        loadImage(
                accommodation.getImagePath()
        );
    }
    
    // ==========================================
    // LOAD LANDLORD DETAILS
    // ==========================================

    private void loadLandlordDetails(
            int accommodationID) {

        AccommodationDAO dao =
                new AccommodationDAO();

        Object[] landlordDetails =
                dao.getLandlordDetails(
                        accommodationID
                );

        if (landlordDetails != null) {

            String firstName =
                    String.valueOf(
                            landlordDetails[0]
                    );

            String lastName =
                    String.valueOf(
                            landlordDetails[1]
                    );

            String email =
                    String.valueOf(
                            landlordDetails[2]
                    );

            String phone =
                    String.valueOf(
                            landlordDetails[3]
                    );

            String dateRegistered;

            if (landlordDetails[4] != null) {

                dateRegistered =
                        landlordDetails[4].toString();

            } else {

                dateRegistered =
                        "Not available";
            }

            lblLandlordName.setText(
                    "Name: "
                    + firstName
                    + " "
                    + lastName
            );

            lblLandlordEmail.setText(
                    "Email: "
                    + email
            );

            lblLandlordPhone.setText(
                    "Phone: "
                    + phone
            );

            lblLandlordDate.setText(
                    "Registered: "
                    + dateRegistered
            );

        } else {

            lblLandlordName.setText(
                    "Name: Not found"
            );

            lblLandlordEmail.setText(
                    "Email: Not found"
            );

            lblLandlordPhone.setText(
                    "Phone: Not found"
            );

            lblLandlordDate.setText(
                    "Registered: Not found"
            );
        }
    }

    // ==========================================
    // LOAD IMAGE
    // ==========================================

    private void loadImage(
            String imagePath) {

        if (imagePath != null &&
                !imagePath.trim().isEmpty() &&
                new File(imagePath).exists()) {

            ImageIcon icon =
                    new ImageIcon(imagePath);

            Image image =
                    icon.getImage()
                    .getScaledInstance(
                            680,
                            230,
                            Image.SCALE_SMOOTH
                    );

            lblImage.setText("");

            lblImage.setIcon(
                    new ImageIcon(image)
            );

        } else {

            lblImage.setIcon(null);

            lblImage.setText(
                    "PROPERTY IMAGE"
            );
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new AccommodationGUI().setVisible(true);

        });
    }
}
