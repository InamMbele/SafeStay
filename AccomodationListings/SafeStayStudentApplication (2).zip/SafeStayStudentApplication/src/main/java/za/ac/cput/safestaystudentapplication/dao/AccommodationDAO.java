package za.ac.cput.safestaystudentapplication.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.*;
import java.util.*;
import za.ac.cput.safestaystudentapplication.connection.DatabaseConnection;
import za.ac.cput.safestaystudentapplication.domain.Accommodation;
/**
 *
 * @author ntando matiwane
 * @studnr 250595699
 */
public class AccommodationDAO {
    
    //ADD or INSERT
    
    public boolean addAccommodation(Accommodation accommodation){
        
        if (!isValidAccommodation(accommodation)) {
            System.out.println("Invalid accommodation information.");
            return false;
        }
        
        String sql = "INSERT INTO ACCOMMODATION " + "(landlordID, name, address, price, numberOfRooms, " + "roomType, distanceToCampus, moveInDate, propertyRules, "
                + "availabilityStatus, dateListed, imagePath) " + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, accommodation.getLandlordID());
            statement.setString(2, accommodation.getName());
            statement.setString(3, accommodation.getAddress());
            statement.setDouble(4, accommodation.getPrice());
            statement.setInt(5, accommodation.getNumberOfRooms());
            statement.setString(6, accommodation.getRoomType());
            statement.setDouble(7, accommodation.getDistanceToCampus());

            if (accommodation.getMoveInDate() != null) {
                statement.setDate(8, Date.valueOf(accommodation.getMoveInDate()));
            } else {
                statement.setNull(8, java.sql.Types.DATE);
            }
            statement.setString(9, accommodation.getPropertyRules());
            statement.setString(10, accommodation.getAvailabilityStatus());

            if (accommodation.getDateListed() != null) {
                statement.setDate(11, Date.valueOf(accommodation.getDateListed()));
            } else {
                statement.setNull(11, java.sql.Types.DATE);
            }

            statement.setString(12, accommodation.getImagePath());

            int rowsInserted = statement.executeUpdate();

            return rowsInserted > 0;

        } catch (SQLException e) {
            System.out.println("Error adding accommodation.");
            e.printStackTrace();
            return false;
        }
    }

    // RETRIEVE ALL or SELECT
    
    public List<Accommodation> getAllAccommodations() {

        List<Accommodation> accommodations = new ArrayList<>();

        String sql = "SELECT * FROM ACCOMMODATION";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {

                Accommodation accommodation = new Accommodation();

                accommodation.setAccommodationID(
                        resultSet.getInt("accommodationID")
                );

                accommodation.setLandlordID(
                        resultSet.getInt("landlordID")
                );

                accommodation.setName(
                        resultSet.getString("name")
                );

                accommodation.setAddress(
                        resultSet.getString("address")
                );

                accommodation.setPrice(
                        resultSet.getDouble("price")
                );

                accommodation.setNumberOfRooms(
                        resultSet.getInt("numberOfRooms")
                );

                accommodation.setRoomType(
                        resultSet.getString("roomType")
                );

                accommodation.setDistanceToCampus(
                        resultSet.getDouble("distanceToCampus")
                );

                Date moveInDate = resultSet.getDate("moveInDate");

                if (moveInDate != null) {
                    accommodation.setMoveInDate(
                            moveInDate.toLocalDate()
                    );
                }

                accommodation.setPropertyRules(
                        resultSet.getString("propertyRules")
                );

                accommodation.setAvailabilityStatus(
                        resultSet.getString("availabilityStatus")
                );

                Date dateListed = resultSet.getDate("dateListed");

                if (dateListed != null) {
                    accommodation.setDateListed(
                            dateListed.toLocalDate()
                    );
                }

                accommodation.setImagePath(
                        resultSet.getString("imagePath")
                );

                accommodations.add(accommodation);
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving accommodations.");
            e.printStackTrace();
        }

        return accommodations;
    }

    // RETRIEVE ONE or SELECT BY ID
    
    public Accommodation getAccommodationById(int accommodationID) {

        String sql = "SELECT * FROM ACCOMMODATION "
                + "WHERE accommodationID = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, accommodationID);

            try (ResultSet resultSet = statement.executeQuery()) {

                if (resultSet.next()) {

                    Accommodation accommodation =
                            new Accommodation();

                    accommodation.setAccommodationID(
                            resultSet.getInt("accommodationID")
                    );

                    accommodation.setLandlordID(
                            resultSet.getInt("landlordID")
                    );

                    accommodation.setName(
                            resultSet.getString("name")
                    );

                    accommodation.setAddress(
                            resultSet.getString("address")
                    );

                    accommodation.setPrice(
                            resultSet.getDouble("price")
                    );

                    accommodation.setNumberOfRooms(
                            resultSet.getInt("numberOfRooms")
                    );

                    accommodation.setRoomType(
                            resultSet.getString("roomType")
                    );

                    accommodation.setDistanceToCampus(
                            resultSet.getDouble("distanceToCampus")
                    );

                    Date moveInDate =
                            resultSet.getDate("moveInDate");

                    if (moveInDate != null) {
                        accommodation.setMoveInDate(
                                moveInDate.toLocalDate()
                        );
                    }

                    accommodation.setPropertyRules(
                            resultSet.getString("propertyRules")
                    );

                    accommodation.setAvailabilityStatus(
                            resultSet.getString("availabilityStatus")
                    );

                    Date dateListed =
                            resultSet.getDate("dateListed");

                    if (dateListed != null) {
                        accommodation.setDateListed(
                                dateListed.toLocalDate()
                        );
                    }

                    accommodation.setImagePath(
                            resultSet.getString("imagePath")
                    );

                    return accommodation;
                }
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving accommodation.");
            e.printStackTrace();
        }

        return null;
    }

    // UPDATE

    public boolean updateAccommodation(Accommodation accommodation) {
        
        if (accommodation == null || accommodation.getAccommodationID() <= 0) {
            System.out.println("Invalid accommodation ID.");
            return false;
        }

        String sql = "UPDATE ACCOMMODATION SET "
                + "landlordID = ?, "
                + "name = ?, "
                + "address = ?, "
                + "price = ?, "
                + "numberOfRooms = ?, "
                + "roomType = ?, "
                + "distanceToCampus = ?, "
                + "moveInDate = ?, "
                + "propertyRules = ?, "
                + "availabilityStatus = ?, "
                + "dateListed = ?, "
                + "imagePath = ? "
                + "WHERE accommodationID = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, accommodation.getLandlordID());
            statement.setString(2, accommodation.getName());
            statement.setString(3, accommodation.getAddress());
            statement.setDouble(4, accommodation.getPrice());
            statement.setInt(5, accommodation.getNumberOfRooms());
            statement.setString(6, accommodation.getRoomType());
            statement.setDouble(7, accommodation.getDistanceToCampus());

            if (accommodation.getMoveInDate() != null) {
                statement.setDate(
                        8,
                        Date.valueOf(accommodation.getMoveInDate())
                );
            } else {
                statement.setNull(8, java.sql.Types.DATE);
            }

            statement.setString(9, accommodation.getPropertyRules());
            statement.setString(10, accommodation.getAvailabilityStatus());

            if (accommodation.getDateListed() != null) {
                statement.setDate(
                        11,
                        Date.valueOf(accommodation.getDateListed())
                );
            } else {
                statement.setNull(11, java.sql.Types.DATE);
            }

            statement.setString(12, accommodation.getImagePath());

            statement.setInt(
                    13,
                    accommodation.getAccommodationID()
            );

            int rowsUpdated = statement.executeUpdate();

            return rowsUpdated > 0;

        } catch (SQLException e) {
            System.out.println("Error updating accommodation.");
            e.printStackTrace();
            return false;
        }
    }
    
    // GET LANDLORD DETAILS
    
    public Object[] getLandlordDetails(int accommodationID) {

        String sql = "SELECT l.firstName, l.lastName, l.email, "
                + "l.phoneNumber, l.dateRegistered "
                + "FROM LANDLORD l "
                + "JOIN ACCOMMODATION a "
                + "ON l.landlordID = a.landlordID "
                + "WHERE a.accommodationID = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, accommodationID);

            try (ResultSet resultSet = statement.executeQuery()) {

                if (resultSet.next()) {

                    return new Object[]{
                        resultSet.getString("firstName"),
                        resultSet.getString("lastName"),
                        resultSet.getString("email"),
                        resultSet.getString("phoneNumber"),
                        resultSet.getDate("dateRegistered")
                    };
                }
            }

        } catch (SQLException e) {

            System.out.println("Error retrieving landlord details.");
            e.printStackTrace();
        }

        return null;
    }
    
    public Object[][] getAllLandlords() {

        ArrayList<Object[]> landlords =
                new ArrayList<>();

        String sql =
                "SELECT landlordID, firstName, lastName "
                + "FROM LANDLORD "
                + "ORDER BY firstName, lastName";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                landlords.add(
                        new Object[]{
                            rs.getInt("landlordID"),
                            rs.getString("firstName"),
                            rs.getString("lastName")
                        }
                );
            }

        } catch (SQLException e) {

            System.out.println("Error retrieving landlords.");
            e.printStackTrace();
        }

        return landlords.toArray(
                new Object[0][]
        );
    }
    
    // DELETE
    
    public boolean deleteAccommodation(int accommodationID) {
        
        if (accommodationID <= 0) {
            System.out.println("Invalid accommodation ID.");
            return false;
        }

        String sql = "DELETE FROM ACCOMMODATION "
                + "WHERE accommodationID = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, accommodationID);

            int rowsDeleted = statement.executeUpdate();

            return rowsDeleted > 0;

        } catch (SQLException e) {
            System.out.println("Error deleting accommodation.");
            e.printStackTrace();
            return false;
        }
    }
    
    // VALIDATE ACCOMMODATION DATA

    private boolean isValidAccommodation(Accommodation accommodation) {

        if (accommodation == null) {
            return false;
        }

        if (accommodation.getLandlordID() <= 0) {
            return false;
        }

        if (accommodation.getName() == null ||
                accommodation.getName().trim().isEmpty()) {
            return false;
        }

        if (accommodation.getAddress() == null ||
                accommodation.getAddress().trim().isEmpty()) {
            return false;
        }

        if (accommodation.getPrice() <= 0) {
            return false;
        }

        if (accommodation.getNumberOfRooms() <= 0) {
            return false;
        }

        if (accommodation.getDistanceToCampus() < 0) {
            return false;
        }

        return true;
    }
}
