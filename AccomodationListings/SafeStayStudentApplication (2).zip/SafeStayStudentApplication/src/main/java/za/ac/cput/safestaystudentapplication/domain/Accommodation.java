package za.ac.cput.safestaystudentapplication.domain;
import java.time.LocalDate;
/**
 *
 * @author ntando matiwane
 * @studnr 250595699
 */
public class Accommodation {
    
    private int accommodationID, landlordID, numberOfRooms;
    private String address, name, roomType, propertyRules, availabilityStatus, imagePath;
    private double price, distanceToCampus;
    private LocalDate moveInDate, dateListed;
    
    public Accommodation(){
        
    }
    
    public Accommodation(int accommodationID, int landlordID, String address, String name, double price, int numberOfRooms, String roomType, double distanceToCampus, LocalDate moveInDate, String propertyRules, String availabilityStatus, LocalDate dateListed, String imagePath) {
        this.accommodationID = accommodationID;
        this.landlordID = landlordID;
        this.address = address;
        this.name = name;
        this.price = price;
        this.numberOfRooms = numberOfRooms;
        this.roomType = roomType;
        this.distanceToCampus = distanceToCampus;
        this.moveInDate = moveInDate;
        this.propertyRules = propertyRules;
        this.availabilityStatus = availabilityStatus;
        this.dateListed = dateListed;
        this.imagePath = imagePath;
    }

    public int getAccommodationID() {
        return accommodationID;
    }

    public void setAccommodationID(int accommodationID) {
        this.accommodationID = accommodationID;
    }

    public int getLandlordID() {
        return landlordID;
    }

    public void setLandlordID(int landlordID) {
        this.landlordID = landlordID;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getNumberOfRooms() {
        return numberOfRooms;
    }

    public void setNumberOfRooms(int numberOfRooms) {
        this.numberOfRooms = numberOfRooms;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public double getDistanceToCampus() {
        return distanceToCampus;
    }

    public void setDistanceToCampus(double distanceToCampus) {
        this.distanceToCampus = distanceToCampus;
    }

    public LocalDate getMoveInDate() {
        return moveInDate;
    }

    public void setMoveInDate(LocalDate moveInDate) {
        this.moveInDate = moveInDate;
    }

    public String getPropertyRules() {
        return propertyRules;
    }

    public void setPropertyRules(String propertyRules) {
        this.propertyRules = propertyRules;
    }

    public String getAvailabilityStatus() {
        return availabilityStatus;
    }

    public void setAvailabilityStatus(String availabilityStatus) {
        this.availabilityStatus = availabilityStatus;
    }

    public LocalDate getDateListed() {
        return dateListed;
    }

    public void setDateListed(LocalDate dateListed) {
        this.dateListed = dateListed;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    @Override
    public String toString() {

        return "Accommodation ID: " + accommodationID
                + "\nLandlord ID: " + landlordID
                + "\nName: " + name
                + "\nAddress: " + address
                + "\nPrice: R" + price
                + "\nNumber of Rooms: " + numberOfRooms
                + "\nRoom Type: " + roomType
                + "\nDistance to Campus: " + distanceToCampus + " km"
                + "\nMove-in Date: " + moveInDate
                + "\nProperty Rules: " + propertyRules
                + "\nAvailability: " + availabilityStatus
                + "\nDate Listed: " + dateListed
                + "\nImage Path: " + imagePath;
    }
}
